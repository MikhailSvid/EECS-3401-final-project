

import java.util.UUID;

public class MealUILauncher {
    private MealUILauncher() {
    }

    /**
     * Launches the meal log screen
     * @param id UUID of user
     */
    public static void launchMealLogScreen(UUID id) {
        MealLogger mealLogger = new MealLogger(id);
        MealLoggerUI screen = new MealLoggerUI(id, mealLogger);
        screen.createMealLogScreen();
    }

    /**
     * Launches the meal journal screen
     * @param id UUID of user
     */
    public static void launchMealJournalScreen(UUID id) {
        MealLogger mealLogger = new MealLogger(id);
        MealJournalUI screen = new MealJournalUI(id, mealLogger);
        screen.createMealJournalScreen();
    }
}
