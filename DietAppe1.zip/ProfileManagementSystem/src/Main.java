
import java.util.List;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {
    public static void main(String[] args) {
        ExerciseLog exerciseLog = new ExerciseLog();
        ExerciseGUI exerciseGUI = new ExerciseGUI("User1", exerciseLog);
        exerciseGUI.createExerciseLogScreen();

         // Verify if the exercise was logged correctly
        printExerciseLog(exerciseLog.getExerciseList());

    }

    // Helper method to print exercise log
    private static void printExerciseLog(List<ExerciseLog.Exercise> exerciseList) {
        System.out.println("Exercise Log:");
        for (ExerciseLog.Exercise exercise : exerciseList) {
            System.out.println("Date: " + exercise.getDate() +
                    ", Time: " + exercise.getTime() +
                    ", Type: " + exercise.getType() +
                    ", Intensity: " + exercise.getIntensity() +
                    ", Duration: " + exercise.getDuration() + " minutes");
        }
    }
    }

