import java.sql.Date;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;
import java.util.UUID;

/**
 * This class is responsible for exercise logging
 */
public class ExerciseLog {

    /**
     * A list that contains the information about the exercise
     */
    private List<Exercise> exerciseList;
    private UUID id;

    /**
     * Constructor to initialize exerciseList
     */
    public ExerciseLog(){
        exerciseList = new ArrayList<>();
    }
    public ExerciseLog(UUID id){
        this.id = id;
    }

    /**
     * @param date a string that is in the form of mm-dd-yyyy
     * @param time a string for the time of the exercise in the form of "XX:XX AM/PM"
     * @param type a string that specifies the type of exercise
     * @param intensity a string that specifies the intensity of the exercise (low, medium, high, very high)
     * @param duration an int that specifies the duration of the exercise in minutes
     */
    public void logExercise(LocalDate date, String time, String type, String intensity, int duration, UUID id){
        //java.sql.Date sqlDate = java.sql.Date.valueOf(LocalDate.parse(date, DateTimeFormatter.ofPattern("MM/dd/yyyy")));
        Exercise exercise = new Exercise(date, time, type, intensity, duration, id);
        exerciseList.add(exercise);
    }


    /**
     * @return returns the list that contains the information about the exercise
     */
    public List<Exercise> getExerciseList() {
        return exerciseList;
    }

    public static List<Exercise> getAllExercises(UUID id){
        if(id==null)
            return new ArrayList<>();
        return ExerciseDataBase.getExerciseForUser(id);
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    /**
     * @param exerciseList list of exercise information
     */
    public void setExerciseList(List<Exercise> exerciseList) {
        this.exerciseList = exerciseList;
    }


    /**
     * A class that is responsible to collect the information about the exercise
     */
    static class Exercise{
        private LocalDate date; // day-month-year
        private String time; // XX:XX AM/PM
        private String type;
        private String intensity; // low, medium, high, very high
        private int duration;  //in minutes
        private double calories;
        private UUID userID;


        public Exercise(){

        }

        /**
         * @param date a string that is in the form of MONTH-DAY-YEAR
         * @param time a string for the time of the exercise in the form of "XX:XX AM/PM"
         * @param type a string that specifies the type of exercise
         * @param intensity a string that specifies the intensity of the exercise (low, medium, high, very high)
         * @param duration an int that specifies the duration of the exercise in minutes
         */
        public Exercise(LocalDate date, String time, String type, String intensity, int duration, UUID id){
            this.date = date;
            this.time = time;
            this.type = type;
            this.intensity = intensity;
            this.duration = duration;
            this.userID = id;
        }

        public UUID getUserID() {
            return userID;
        }

        public void setUserID(UUID userID) {
            this.userID = userID;
        }

        /**
         * @return String date of exercise
         */
        public Date getDate() {

        	return Date.valueOf(date);
        }

        /**
         * @param date sets date if exercise
         */
        public void setDate(LocalDate date) {
            this.date = date;
        }

        /**
         * @return String time of exercise
         */
        public String getTime() {
            return time;
        }

        /**
         * @param time sets time of exercise
         */
        public void setTime(String time) {
            this.time = time;
        }

        /**
         * @return a String type of exercise
         */
        public String getType() {
            return type;
        }

        /**
         * @param type sets type of exercise
         */
        public void setType(String type) {
            this.type = type;
        }

        /**
         * @return String intensity of exercise
         */
        public String getIntensity() {
            return intensity;
        }

        /**
         * @param intensity sets intensity of exercise
         */
        public void setIntensity(String intensity) {
            this.intensity = intensity;
        }

        /**
         * @return int duration of exercise
         */
        public int getDuration() {
            return duration;
        }

        /**
         * @param duration sets duration of exercise
         */
        public void setDuration(int duration) {
            this.duration = duration;
        }

        public double getCalories() {
            return ExerciseGUI.caloriesBurnt();
        }

        public void setCalories(double calories) {
            this.calories = calories;
        }
    }

}