
public class HeightConverter extends MeritUnitConverter{
	public double getImperial(double value) {
		return value * 2.54;
		
	}
	public double getMetric(double value) {
		return value / 2.54; 
	}
}
