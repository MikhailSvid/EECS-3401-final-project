import java.util.HashMap;
import java.util.Map;
import java.util.Set;


public class ProfileManager {
	static Profile loggedInProfile;
	private static Map<String, String []> profiles = new HashMap<>();
	
	public void createProfile(String username, String password, String dob, String sex, double height, double weight, String meritUnits){
		Profile newProfile = new Profile(username, password, dob, sex, weight, height, meritUnits);
		loggedInProfile = newProfile;
		String[] PassId = {password, loggedInProfile.id};
		profiles.put(username, PassId);
	}
	
	public void loadProfiles() {
		ProfilesDB db = new ProfilesDB();
		profiles = db.loadProfiles();
	}
	
	public boolean login (String username, String password) {
		if (profiles.get(username) == null) {
			return false;
		}
		if (!profiles.get(username)[0].equals(password)){
			return false;
		}
		
		loggedInProfile = new Profile(profiles.get(username)[1]);
		
		//MealLogger mlogger = new MealLogger();
		//mLogger.loadLogs(profiles.get(username)[1]);
		//ExerciseLogger elogger = new ExerciseLogger();
		//eLogger.loadLogs(profiles.get(username)[1]);
		this.display();
		return true;
		
		
	}
	
	public void logout() {
		loggedInProfile = null;
	}
	
	public void display() {
		System.out.println(loggedInProfile);
	}
	
	public Set<String> getUsernames(){
		return profiles.keySet();
	}
	
	public Profile getLoggedIn() {
		return loggedInProfile;
	}
	
}
