import javax.swing.JFrame;
import javax.swing.JPanel;

public class SettingsScreen {
	private JFrame frame;
	private JPanel panel;
	
	public SettingsScreen() {
		initialize();
	}
	private void initialize() {
		this.setFrame();
		this.setPanel();
		frame.add(panel);
	}
	private void setFrame() {
		frame = new JFrame();
		frame.setTitle("Profile");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setSize(1000, 900);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setVisible(true);
	}
	private void setPanel() {
		panel = new JPanel();
		panel.setLayout(null);
	}
}
