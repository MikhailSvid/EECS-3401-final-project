public class client {
//	public static void main (String[] args){
//		ProfileManager profileManager = new ProfileManager();
//		
//		profileManager.createProfile("Mikhail", "1234", "2002-09-09", "male", 180, 60, "Imperial");
//		profileManager.logout();
//		profileManager.login("Mikhail", "123");
//		profileManager.login("Mikhail", "1234");
//		profileManager.display();
//		profileManager.logout();
//		
//		profileManager.createProfile("Maria", "password", "2004-08-07", "female", 150, 40, "Imperial");
//		profileManager.logout();
//		profileManager.login("Maria", "password");
//		profileManager.display();
//		profileManager.logout();
//	}
}
