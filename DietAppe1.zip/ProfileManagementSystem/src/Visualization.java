	
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.chart.plot.XYPlot; 



public class Visualization {
		
		public JFreeChart graphNutrientIntake(LocalDate start, LocalDate end, UUID id) {	
			System.out.println("check");
			List<MealLog> meallogs = MealLogger.getMealLogs(id, start, end);
			double carbohydrates = 0;
			double protiens = 0;
			double sugar = 0;
			double iron = 0;
			double sodium = 0;
			double vitaminC = 0;
			double vitaminD = 0;
			
			for(MealLog e : meallogs) {
				carbohydrates += e.getNutrients().get("Carbohydrates (g)");
				protiens += e.getNutrients().get("Protein (g)");
				sugar += e.getNutrients().get("Sugar (g)");
				iron += e.getNutrients().get("Iron (mg)");
				sodium += e.getNutrients().get("Sodium (mg)");
				vitaminC += e.getNutrients().get("Vitamin C (mg)");
				vitaminD += e.getNutrients().get("Vitamin D (IU)");
			}

			carbohydrates *= 1000;
			protiens *= 1000;
			sugar *= 1000;
			vitaminD *= 0.67;
			
			System.out.println("carbohydrates " + carbohydrates);
			System.out.println("protiens " + protiens);
			System.out.println("sugar " + sugar);
			System.out.println("iron " + iron);
			System.out.println("sodium " + sodium);
			System.out.println("vitaminC " + vitaminC);
			System.out.println("vitaminD " + vitaminD);
			
			ArrayList<Double> sorting = new ArrayList<Double>(); 
			sorting.add(carbohydrates);
			sorting.add(protiens);
			sorting.add(sugar);
			sorting.add(iron);
			sorting.add(sodium);
			sorting.add(vitaminC);
			sorting.add(vitaminD);

			Collections.sort(sorting);
			System.out.println(sorting);
			Set<String> topFive = new HashSet<String>();
			
			for(int i = sorting.size()-1; i >= 2; i--) {
				System.out.println(i + " " + sorting.get(i));
				if(sorting.get(i) == carbohydrates) {
					topFive.add("Carbohydrates (g)");
				}
				else if(sorting.get(i) == protiens) {
					topFive.add("Protein (g)");
				}
				else if(sorting.get(i) == sugar) {
					topFive.add("Sugar (g)");
				}
				else if(sorting.get(i) == iron) {
					topFive.add("Iron (mg)");
				}
				else if(sorting.get(i) == sodium) {
					topFive.add("Sodium (mg)");
				}
				else if(sorting.get(i) == vitaminC) {
					topFive.add("Vitamin C (mg)");
				}
				else {
					topFive.add("Vitamin D (IU)");
				}
			}
			
			Set<String> others = new HashSet<String>();
			

			for(int i = 0; i < 2; i++) {
				if(sorting.get(i) == carbohydrates) {
					others.add("Carbohydrates (g)");
				}
				else if(sorting.get(i) == protiens) {
					others.add("Protein (g)");
				}
				else if(sorting.get(i) == sugar) {
					others.add("Sugar (g)");
				}
				else if(sorting.get(i) == iron) {
					others.add("Iron (mg)");
				}
				else if(sorting.get(i) == sodium) {
					others.add("Sodium (mg)");
				}
				else if(sorting.get(i) == vitaminC) {
					others.add("Vitamin C (mg)");
				}
				else {
					others.add("Vitamin D (IU)");
				}
			}
			
			System.out.println(topFive);
			System.out.println(others);
	    	DefaultCategoryDataset dataset = new DefaultCategoryDataset();
			
			for(MealLog e : meallogs) {
				int temp = 0;
				for(String o : others) {
					temp = e.getNutrients().get(o) + temp;
				}
				dataset.addValue( temp , "Other"  , e.getDate());
				for(String s : topFive) {
					dataset.addValue( e.getNutrients().get(s) , s , e.getDate());
				}
				temp = 0;
			}
			return this.graphBarchart(dataset);
		}

		public JFreeChart graphCaloryIntake(LocalDate start, LocalDate end, String graphType, UUID id) {
			
			  List<MealLog> meallogs = MealLogger.getMealLogs(id, start, end);
			  	  
		      if(graphType.equals("Bar Graph")) {
		    	  
		    	  DefaultCategoryDataset dataset = new DefaultCategoryDataset();
				  for(MealLog e : meallogs) {
					  dataset.addValue(e.getNutrients().get("Calories"), "Calorie Intake", e.getDate().toString());
				  }
		    	  
		    	  return graphBarchart(dataset);
		      }
		      else if (graphType.equals("Line Graph")){
		    	  
		    	  DefaultCategoryDataset dataset = new DefaultCategoryDataset();
				  for(MealLog e : meallogs) {
					  dataset.addValue(e.getNutrients().get("Calories"), "Calorie Intake", e.getDate().toString());
					  System.out.println(e.getNutrients().get("Calories"));
				  }
				  
		    	  return graphLinechart(dataset);
		      }
		      else {
		    	  
//		    	  XYSeries series = new XYSeries(graphType);
//		    		  
//				  for(MealLog e : meallogs) {
//					  series.add(e.getDate().toString(),  e.getNutrients().get("Calories"));
//				  }
//				  
//				  XYSeriesCollection dataset = new XYSeriesCollection();
//				  
//			      dataset.addSeries(series);
//				  
//			      XYDataset XYdata = dataset;
//			      
//			      graphScatterChart(XYdata);
		      }
		      return null;
		}
		
		
		private JFreeChart graphBarchart(DefaultCategoryDataset dataset) {
			
		      JFreeChart barChart = ChartFactory.createBarChart(
	    	         	"Calory Intake",
	    	         	"Date","Calories",
	    	         	dataset,
	    	         	PlotOrientation.VERTICAL,
	    	         	true,true,false);
		
	      return barChart;
		}
			
		private JFreeChart graphLinechart(DefaultCategoryDataset dataset) {
			
		      JFreeChart lineChart = ChartFactory.createLineChart(
	    	         	"Calory Intake",
	    	         	"Date","Calories",
	    	         	dataset,
	    	         	PlotOrientation.VERTICAL,
	    	         	true,true,false);
		
	      return lineChart;
		}
		
		private JFreeChart graphScatterChart(XYDataset dataset) {
			
		      JFreeChart scatterChart = ChartFactory.createScatterPlot(
	    	         	"Calory Intake",
	    	         	"Date","Calories",
	    	         	dataset,
	    	         	PlotOrientation.VERTICAL,
	    	         	true,true,false);
		
	      return scatterChart;
		}
		

//		public void graphTDEE(Date start, Date end) {
//			
//			List<ExerciseLog.Exercise> exerciselogs = Exercise.getExerciseLogs(id, start, end);
//			ProfileManager manager = new ProfileManager();
//		  	  
//		      if(graphType.equals("Bar Chart")) {
//		    	  
//		    	  DefaultCategoryDataset dataset = new DefaultCategoryDataset();
//		    	  
//				  for(ExerciseLog.Exercise e : exerciselogs) {
//					  dataset.setValue(e.getDate(), Calculation.calcTDEE(e.getIntesity, manager.getLoggedIn().getBmr()));
//				  }
//		    	  
//		    	  graphBarchart(dataset);
//		      }
//		      else if (graphType.equals("Line Chart")){
//		    	  
//		    	  DefaultCategoryDataset dataset = new DefaultCategoryDataset();
//		    	  
//				  for(ExerciseLog.Exercise e : exerciselogs) {
//					  dataset.setValue(e.getDate(), Calculation.calcTDEE(e.getIntesity, manager.getLoggedIn().getBmr()));
//				  }
//		    	  
//		    	  graphLinechart(dataset);
//		      }
//		      else {
//		    	  
//		    	  XYSeries series = new XYSeries(graphType);
//		    		  
//				  for(ExerciseLog.Exercise e : exerciselogs) {
//					  series.add(e.getDate(),  Calculation.calcTDEE(e.getIntesity, manager.getLoggedIn().getBmr()));
//				  }
//				  
//				  XYSeriesCollection dataset = new XYSeriesCollection();
//				  
//			      dataset.addSeries(series);
//				  
//			      XYDataset XYdata = dataset;
//			      
//			      graphScatterChart(XYdata);
//		      }
//			
//		}
//
		public static JFreeChart getCFChart() {
				
			DefaultPieDataset cfPlate = new DefaultPieDataset();	
				
			cfPlate.setValue("Vegetables and Fruit", 50);
			cfPlate.setValue("Protein", 25);
			cfPlate.setValue("Whole Grains", 25);
			
			
	        JFreeChart chart = ChartFactory.createPieChart(
		            "Canada Food Guide 2019",
		            cfPlate,
		            true,
		            true,
		            false
	        	);
			
	        return chart;
		}

		public void plotUserPlate() {
			DefaultPieDataset userPlate = new DefaultPieDataset();	
			
			
		}
//
//		public void showUserPlate(DefaultPieDataset userPlate) {
//					
//			
//		}
//		
//		public static void testing() {
//			
//		      DefaultCategoryDataset dataset = new DefaultCategoryDataset( );
//		      dataset.addValue( 15 , "schools" , "1970" );
//		      dataset.addValue( 30 , "schools" , "1980" );
//		      dataset.addValue( 60 , "schools" ,  "1990" );
//		      dataset.addValue( 120 , "schools" , "2000" );
//		      dataset.addValue( 240 , "schools" , "2010" );
//		      dataset.addValue( 300 , "schools" , "2014" );
//		      dataset.addValue( 23 , "balls" , "1970" );
//		      dataset.addValue( 55, "balls" , "1980" );
//		      dataset.addValue( 100 , "balls" ,  "1990" );
//		      dataset.addValue( 169 , "balls" , "2000" );
//		      dataset.addValue( 270 , "balls" , "2010" );
//		      dataset.addValue( 290 , "balls" , "2014" );
//			
//		      JFreeChart lineChart = ChartFactory.createLineChart(
//		    	         	"Line Graph",
//		    	         	"Years","Number of Schools",
//		    	         	dataset,
//		    	         	PlotOrientation.VERTICAL,
//		    	         	true,true,false);
//		      
//		      ChartFrame frame = new ChartFrame("First", lineChart);
//		      frame.pack();
//		      frame.setVisible(true);
//		}
//
//
//	    public static void main(String[] args) {
//	    	testing();
//	    }

	    
}