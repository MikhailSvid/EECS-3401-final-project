
public class VolumeConverter extends MeritUnitConverter {
	public double getImperial(double value) {
		return value * 29.574;
		
	}
	public double getMetric(double value) {
		return value / 29.574; 
	}
}
