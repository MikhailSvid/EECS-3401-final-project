

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

public class MealJournalUI implements ActionListener{
    private UUID id;
    private MealLogger mealLogger;
    private static List<MealLog> mealObjects;


    private static JComboBox<String> mealDropdown;
    private static DefaultTableModel tableModel;

    protected MealJournalUI(UUID id, MealLogger mealLogger){
        this.id = id;
        this.mealLogger = mealLogger;
    }

    protected void createMealJournalScreen(){
        JFrame frame = new JFrame("Meal Journal for " + id.toString());
        JPanel panel = new JPanel();
        frame.setSize(950, 600);
        //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);

        panel.setLayout(null);

        /*
            Meal Selector
         */
        JLabel selectLabel = new JLabel("Select a meal");
        selectLabel.setBounds(400, 15, 300, 25);
        panel.add(selectLabel);

        List<String> meals = getSortedMealJournalLogs();
        mealDropdown = new JComboBox<>(meals.toArray(new String[0]));
        mealDropdown.setBounds(275, 50, 350, 25);
        mealDropdown.setMaximumRowCount(20);
        panel.add(mealDropdown);

        JButton addLogButton = new JButton("View Nutrients");
        addLogButton.setBounds(375, 90, 130, 40);
        addLogButton.addActionListener(new MealJournalUI(id, mealLogger));
        panel.add(addLogButton);

        /*
            Nutrient Table
         */
        String[] columnNames = {"Nutrient:", "Amount:"};
        String[][] data = {
                {"Nutrient:", "Amount:"},
                {"Calories", },
                {"Carbohydrates (g)", },
                {"Protein (g)", },
                {"Sugar (g)", },
                {"Iron (mg)", },
                {"Sodium (mg)", },
                {"Vitamin C (mg)", },
                {"Vitamin D (IU)", }
        };
        tableModel = new DefaultTableModel(data, columnNames);
        JTable table = new JTable(tableModel);
        table.setBounds(300, 200, 300, 300);
        table.setRowHeight(30);
        Font font = table.getFont();
        Font newFont = new Font(font.getFontName(), font.getStyle(), 15);
        table.setFont(newFont);
        panel.add(table);

        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        int index = mealDropdown.getSelectedIndex();
        if (index == 0) return;
        MealLog meal = mealObjects.get(index);
        String[][] data = {
                {"Nutrient:", "Amount:"},
                {"Calories", ""},
                {"Carbohydrates (g)", ""},
                {"Protein (g)", ""},
                {"Sugar (g)", ""},
                {"Iron (mg)", ""},
                {"Sodium (mg)", ""},
                {"Vitamin C (mg)", ""},
                {"Vitamin D (IU)", ""}
        };
        tableModel.setRowCount(0);
        tableModel.addRow(data[0]);
        for (int i = 1; i < 9; i++) {
            data[i][1] = meal.getNutrients().get(data[i][0]).toString();
            tableModel.addRow(data[i]);
        }
    }

    private List<String> getSortedMealJournalLogs() {
        List<MealLog> mealLogs= MealLogger.getAllMealLogs(id);
        mealLogs.sort(Comparator.comparing(MealLog::getDate)
                .thenComparing(MealLog::getMealType, Comparator.comparingInt(MealJournalUI::orderOfMealType)));

        List<String> meals = new ArrayList<>();
        // List<MealLog> mealObjects stores the meal objects in the same order as the strings in List<String> meals, for looking up nutrient info later
        mealObjects = new ArrayList<>();

        for (MealLog mealLog : mealLogs) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            meals.add(mealLog.getMealType() + " on " + mealLog.getDate().format(formatter) + "  -----  Calories: " + mealLog.getNutrients().get("Calories"));
            mealObjects.add(mealLog);
        }

        meals.add(0, "");
        if (meals.size() == 1) {
            meals.clear();
            meals.add("No meals found");
        }
        mealObjects.add(0, null);

        return meals;
    }

    private static int orderOfMealType(String mealType) {
        return switch (mealType) {
            case "Breakfast" -> 1;
            case "Lunch" -> 2;
            case "Dinner" -> 3;
            case "Snack" -> 4;
            default -> 5;
        };
    }
}