

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.*;

public class MealLogDataBase {
    private static final String url = "jdbc:mysql://localhost:3306/profiles";
    private static final String username = "root";
    private static final String password = "Misha7820!";

    private static final String foodNameCsvFilePath = "src/resources/FOOD_NAME.csv";
    private static final String nutrientAmountCsvFilePath = "src/resources/NUTRIENT_AMOUNT.csv";

    private MealLogDataBase() {
    }

    /**
     * Loads the food names and nutrient amounts csv files into the MySQL database if they have not already been
     */
    public static void loadFoodAndNutrientDatabase() {
        try {
            Connection connection = DriverManager.getConnection(url, username, password);

            Statement statement = connection.createStatement();

            try {
                statement.executeQuery("SELECT * FROM FoodNames;");
                // Food And Nutrient Database has already been initialized
                return;
            }
            catch (Exception ignored) {}

            statement.executeUpdate(("CREATE TABLE IF NOT EXISTS FoodNames (" +
                    "FoodID VARCHAR(255) NOT NULL," +
                    "FoodDescription TEXT," +
                    "PRIMARY KEY (FoodID));"
            ));

            String line = "";
            int currentRow = 1;
            try {
                BufferedReader br = new BufferedReader(new FileReader(foodNameCsvFilePath));
                while ((line = br.readLine()) != null) {
                    if (currentRow >= 1) {
                        String[] cells = line.split("\"");
                        try {
                            if (!cells[1].contains("\uFFFD")) {
                                String foodID = cells[0].split(",")[0];
                                String foodDescription = cells[1];
                                String insertStatement = "INSERT INTO FoodNames (FoodID, FoodDescription) " +
                                        "VALUES ('" + foodID + "', '" + foodDescription + "');";
                                statement.executeUpdate(insertStatement);
                            }
                        } catch (Exception ignored) {}
                    }
                    currentRow++;
                    if (currentRow > 5692) break;
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            statement.executeUpdate(("CREATE TABLE IF NOT EXISTS NutrientAmounts (" +
                    "FoodID VARCHAR(255) NOT NULL," +
                    "NutrientID VARCHAR(255)," +
                    "NutrientValue VARCHAR(255));"
            ));

            line = "";
            currentRow = 1;
            try {
                BufferedReader br = new BufferedReader(new FileReader(nutrientAmountCsvFilePath));
                while ((line = br.readLine()) != null) {
                    if (currentRow >= 1) {
                        String[] cells = line.split(",");
                        try {
                            String insertStatement = "INSERT INTO NutrientAmounts (FoodID, NutrientID, NutrientValue) " +
                                    "VALUES ('" + cells[0] + "', '" + cells[1] + "', '" + cells[2] + "');";
                            statement.executeUpdate(insertStatement);
                        } catch (Exception ignored) {}
                    }
                    currentRow++;
                    if (currentRow > 524674) break;
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }

    protected static String getIngredientID(String ingredient) {
        String ingredientID = "";

        try {
            Connection connection = DriverManager.getConnection(url, username, password);

            Statement statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery("SELECT * FROM FoodNames WHERE FoodDescription ='" + ingredient + "';");

            while (resultSet.next()) {
                ingredientID = resultSet.getString("FoodID");
            }
        }
        catch (Exception e) {
            System.out.println(Arrays.toString(e.getStackTrace()));
        }

        return ingredientID;
    }

    protected static Double getNutrients(String ingredientID, String nutrientID) {
        Double nutrientAmount = 0.0;

        try {
            Connection connection = DriverManager.getConnection(url, username, password);

            Statement statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery("SELECT * FROM NutrientAmounts WHERE FoodID ='" + ingredientID + "';");

            while (resultSet.next()) {
                if (resultSet.getString("NutrientID").equals(nutrientID)) {
                    nutrientAmount = Double.parseDouble(resultSet.getString("NutrientValue"));
                }
            }
        }
        catch (Exception e) {
            System.out.println(Arrays.toString(e.getStackTrace()));
        }

        return nutrientAmount;
    }

    protected static List<String> getAllIngredients() {
        List<String> ingredients = new ArrayList<>();

        try {
            Connection connection = DriverManager.getConnection(url, username, password);

            Statement statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery("SELECT * FROM FoodNames;");

            while (resultSet.next()) {
                ingredients.add(resultSet.getString("FoodDescription"));
            }

            ingredients.sort(String.CASE_INSENSITIVE_ORDER);
            ingredients.add(0, "");
        }
        catch (Exception e) {
            System.out.println(Arrays.toString(e.getStackTrace()));
        }

        return ingredients;
    }

    protected static void write(String command) {
        try {
            Connection connection = DriverManager.getConnection(url, username, password);

            Statement statement = connection.createStatement();

            statement.executeUpdate(("CREATE TABLE IF NOT EXISTS MealLogs (" +
                    "MealID VARCHAR(255) NOT NULL," +
                    "UserID VARCHAR(255)," +
                    "Date DATE," +
                    "MealType VARCHAR(255)," +
                    "Ingredients TEXT," +
                    "Quantities TEXT," +
                    "Nutrients TEXT," +
                    "PRIMARY KEY (MealID));"
            ));

            statement.executeUpdate(command);
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }

    protected static List<MealLog> getMealsForUser(UUID id) {
        List<MealLog> mealLogs = new ArrayList<>();

        try {
            Connection connection = DriverManager.getConnection(url, username, password);

            Statement statement = connection.createStatement();

            statement.executeUpdate(("CREATE TABLE IF NOT EXISTS MealLogs (" +
                    "MealID VARCHAR(255) NOT NULL," +
                    "UserID VARCHAR(255)," +
                    "Date DATE," +
                    "MealType VARCHAR(255)," +
                    "Ingredients TEXT," +
                    "Quantities TEXT," +
                    "Nutrients TEXT," +
                    "PRIMARY KEY (MealID));"
            ));

            ResultSet resultSet = statement.executeQuery("SELECT * FROM MealLogs WHERE UserID ='" + id.toString() + "';");

            while (resultSet.next()) {
                HashMap<String, Integer> ingredientsAndQuantities = new HashMap<>();
                String[] ingredients = resultSet.getString("Ingredients").split("\\|");
                String[] quantities = resultSet.getString("Quantities").split("\\|");
                for (int i = 0; i < ingredients.length; i++) {
                    ingredientsAndQuantities.put(ingredients[i], Integer.parseInt(quantities[i]));
                }

                List<Integer> nutrientsList = new ArrayList<>();
                String[] nutrients = resultSet.getString("Nutrients").split("\\|");

                for (int i = 0; i < nutrients.length; i++) {
                    nutrientsList.add(Integer.parseInt(nutrients[i]));
                }

                MealLog mealLog = new MealLog(
                        UUID.fromString(resultSet.getString("MealID")),
                        UUID.fromString(resultSet.getString("UserID")),
                        resultSet.getDate("Date").toLocalDate(),
                        resultSet.getString("MealType"),
                        ingredientsAndQuantities,
                        nutrientsList
                );

                mealLogs.add(mealLog);
            }
        }
        catch (Exception e) {
            System.out.println(Arrays.toString(e.getStackTrace()));
        }

        return mealLogs;
    }
}
