import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
public class AgeCalculator {
	public static long getAge(LocalDate dob) {
	    LocalDate currentDate = LocalDate.now();
	    long age = ChronoUnit.YEARS.between(dob, currentDate);
	    return age;
	}
}
