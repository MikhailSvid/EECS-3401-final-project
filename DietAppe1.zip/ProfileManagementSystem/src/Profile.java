import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.HashSet;
import java.util.Random;

public class Profile {
	String username;
	String password;
	double weight;
	double height;
	String sex;
	String meritUnits;
	LocalDate dob;
	String id;
	double bmr;
	double bmi;
	static Collection<Integer> ids = new HashSet<>();
	  DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	
	public Profile(String id) {
		ProfilesDB db = new ProfilesDB();
		db.loadProfileData(id, this);
	}
	
	public Profile(String username, String password, String dob, String sex, double weight, double height, String meritUnits){
		this.username = username;
		this.password = password;
	
		this.dob = LocalDate.parse(dob, format);

		
		this.sex = sex;
		this.height = height;
		this.weight = weight;
		this.meritUnits = meritUnits;
		
		id = this.getId();
		this.bmi = Calculation.calcBMI(weight, height, meritUnits);
		this.bmr = Calculation.calcBMR(weight, height, sex, AgeCalculator.getAge(this.dob), meritUnits);
		ProfilesDB db = new ProfilesDB();
		db.writeProfile(id, username, password, dob, sex, weight, height, meritUnits, bmi, bmr);
		
	}
	
	private String getId() {
		Random rand = new Random();
		int num = rand.nextInt(99999);
		while (ids.contains(num)) {
			num = rand.nextInt(99999);
		}
		ids.add(num);
		return String.format("%05d", num);
	}
	
	public void setID(String id) {
		this.id = id;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}
	
	public void setDoB(LocalDate dob) {
		this.dob = dob;
	}

	public void setBMI(double bmi) {
		this.bmi = bmi;
	}
	
	public void setBMR(double bmr) {
		this.bmr = bmr;
	}
	
	public void setMeritUnits(String meritUnits) {
		this.meritUnits = meritUnits;
	}
	
	
	public String getID() {
		return id;
	}
	
	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public double getWeight() {
		return weight;
	}

	public double getHeight() {
		return height;
	}

	public String getSex() {
		return sex;
	}

	public String getMeritUnits() {
		return meritUnits;
	}

	public LocalDate getDob() {
		return dob;
	}
	
	public double getBmi() {
		return bmi;
	}
	
	public double getBmr() {
		return bmr;
	}


	public void convertToMerit() {
		MeritUnitConverter heightConverter = new HeightConverter();
		MeritUnitConverter weightConverter = new WeightConverter();
		height = heightConverter.getMetric(height);
		weight = weightConverter.getMetric(weight);
		meritUnits = "Metric";
	}
	
	public void convertToImperial() {
		MeritUnitConverter heightConverter = new HeightConverter();
		MeritUnitConverter weightConverter = new WeightConverter();
		height = heightConverter.getImperial(height);
		weight = weightConverter.getImperial(weight);
		meritUnits = "Imperial";
	}
	
	@Override
	public String toString() {
		return String.format("ID: %s\nUsername: %s\nPassword: %s\nDate of Birth: %s\nSex: %s\nHeight: %.2f\nWeight: %.2f\nMerit Units: %s\nBMI: %.2f\nBMR: %.2f",
				id, username, password, format.format(dob), sex, height, weight, meritUnits, bmi, bmr);
	}
	
}
