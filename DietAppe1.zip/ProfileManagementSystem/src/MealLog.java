

import java.time.LocalDate;
import java.util.*;

public class MealLog {
	// Stores nutrient name and nutrient ID
	protected static final String[][] NUTRIENT_NAMES_AND_IDS = {{"Calories", "208"}, {"Carbohydrates (g)", "205"}, {"Protein (g)", "203"}, {"Sugar (g)", "269"},
			{"Iron (mg)", "303"}, {"Sodium (mg)", "307"}, {"Vitamin C (mg)", "401"}, {"Vitamin D (IU)", "324"}};
	private UUID mealID;
	private UUID userID;
	private LocalDate date;
	private String mealType;
	private HashMap<String, Integer> ingredients;
	private List<Integer> nutrients;

	protected MealLog(UUID mealID, UUID userID, LocalDate date, String mealType, HashMap<String, Integer> ingredients, List<Integer> nutrients) {
		this.mealID = mealID;
		this.userID = userID;
		this.date = date;
		this.mealType = mealType;
		this.ingredients = ingredients;
		this.nutrients = nutrients;
	}

	/**
	 * @return UUID of meal
	 */
	public UUID getMealID() {
		return mealID;
	}

	/**
	 * @return UUID of user who logged this meal
	 */
	public UUID getUserID() {
		return userID;
	}

	/**
	 * @return date of the meal
	 */
	public LocalDate getDate() {
		return date;
	}

	/**
	 * @return type of meal. (Breakfast, Lunch, Dinner, or Snack)
	 */
	public String getMealType() {
		return mealType;
	}

	/**
	 * @return hashmap of between 1-4 ingredients used in this meal
	 * Formatted as: {Ingredient name, Quantity in grams}
	 */
	public HashMap<String, Integer> getIngredients() {
		return ingredients;
	}

	/**
	 * @return hashmap of name and quantity of 8 different nutrients in the meal
	 * Formatted as:
	 * {Calories, Quantity}
	 * {Carbohydrates (g), Quantity in grams}
	 * {Protein (g), Quantity in grams}
	 * {Sugar (g), Quantity in grams}
	 * {Iron (mg), Quantity in milligrams}
	 * {Sodium (mg), Quantity in milligrams}
	 * {Vitamin C (mg), Quantity in milligrams}
	 * {Vitamin D (IU), Quantity in international units}
	 */
	public HashMap<String, Integer> getNutrients() {
		HashMap<String, Integer> nutrients = new HashMap<>();
		for (int i = 0; i < NUTRIENT_NAMES_AND_IDS.length; i++) {
			nutrients.put(NUTRIENT_NAMES_AND_IDS[i][0], this.nutrients.get(i));
		}
		return nutrients;
	}

	@Override
	public String toString() {
		return "MealLog{" +
				"mealID=" + mealID +
				", userID=" + userID +
				", date=" + date +
				", mealType='" + mealType + '\'' +
				", ingredients=" + ingredients +
				", nutrients=" + getNutrients() +
				'}';
	}
}
