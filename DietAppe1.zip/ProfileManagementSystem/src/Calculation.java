
import java.lang.Math;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


public class Calculation {
	
	
	public static double calcCaloriesBurnt(String intensity, double duration) {
		double met;
		
		if (intensity.equals("low")) {
			met = 2.9;
		}
		else if (intensity.equals("medium")) {
			met = 4.5;
		}
		else if (intensity.equals("high")) {
			met = 7.5;
		}
		else {
			met = 9;
		}
		ProfileManager manager = new ProfileManager();
		long age = AgeCalculator.getAge(manager.getLoggedIn().getDob());
		
		double bmr = Calculation.calcBMR(manager.getLoggedIn().getWeight(), manager.getLoggedIn().getHeight(), 
				manager.getLoggedIn().getSex(), age, manager.getLoggedIn().getMeritUnits());
		double  burnt = met * bmr * (duration / 60);
		
		
		return burnt;
	}
	
	public static double calcFatBurnt(LocalDate end) {
		ProfileManager manager = new ProfileManager();
		List <MealLog> mealLogs = MealLogger.getAllMealLogs(UUID.fromString("3a86a95e-81e1-4fae-9533-3cafaf726bc3"));
		List<ExerciseLog.Exercise> exerciseLogs = new ArrayList<>();
		double calorieTaken = 0;
		double calorieBurnt = 0;
		LocalDate firstLog = mealLogs.get(0).getDate();
		for (MealLog e : mealLogs) {
			calorieTaken += e.getNutrients().get("Calories");
			if (e.getDate().isBefore(firstLog)) {
				firstLog = e.getDate();
			}
		}
		for (ExerciseLog.Exercise e : exerciseLogs) {
			calorieBurnt += Calculation.calcCaloriesBurnt(e.getIntensity(), e.getDuration());
		}
		
		LocalDate currentDate = LocalDate.now();
	    long days = ChronoUnit.DAYS.between(firstLog, currentDate);
	    double avarageCaloriesBurnt = (calorieBurnt - calorieTaken)/days;
	    
	    days = ChronoUnit.DAYS.between(currentDate, end);

		return (days * avarageCaloriesBurnt) / 7700000;
	}

	public static double calcBMI(double weight, double height, String meritUnits) {
		
		double bmi = 0;
		if(meritUnits.compareTo("Imperial") == 1)
			weight = weight / 2.205;

		if(meritUnits.compareTo("Imperial") == 1)
			height = height * 2.205;
		
		bmi = weight/(height*height) * 10000;
		
		
		return bmi;
	}

	public static double calcBMR(double weight, double height, String sex, long age, String meritUnits) {
		
		double bmr = 0;
		
		if(meritUnits.compareTo("Imperial") == 1)
			weight = weight / 2.205;

		if(meritUnits.compareTo("Imperial") == 1)
			height = height * 2.205;
		

		if(sex.compareTo("Male") == 1) {
			bmr = (88.4 + 13.4 * weight) + (4.8 * height) - (5.68 * age);
		}
		else {
			bmr = (447.6 + 9.25 * weight) + (3.10 * height) - (4.33 * age);
		}
		
		return bmr;
	}
	
	public static double calcTDEE(double bmr, String intensity) {
		double aFactor;
		if (intensity.equals("low")) {
			aFactor = 1.375;
		}
		else if (intensity.equals("medium")) {
			aFactor = 1.55;
		}
		else if (intensity.equals("high")) {
			aFactor = 1.725;
		}
		else {
			aFactor = 1.9;
		}
		
		return bmr * aFactor;
	}


}
