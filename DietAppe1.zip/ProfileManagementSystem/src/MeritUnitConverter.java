
public abstract class MeritUnitConverter {
	public abstract double getImperial(double value);
	public abstract double getMetric(double value);
}
