import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.UUID;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

public class MainScreen {
	private JFrame frame;
	private JPanel panel;
	private JTextField graph1;
	private JTextField graph2;
	private JTextField graph3;
	private JTabbedPane graphs;
	private JPanel caloryIntake;
	private JPanel tdee;
	private JPanel nutrientIntake;
	private JPanel pieCharts;
	
	private ChartPanel caloryIntakePanel;
	private ChartPanel tdeePanel;
	private ChartPanel nutrientIntakePanel;
	
	private JButton plot1;
	private JButton plot2;
	private JButton plot3;
	private JButton calculate1;
	private JButton calculate2;
	private JButton calculate3;
	private JButton mealJournal;
	
	private JTextField from1;
	private JLabel from1Error;
	private JTextField from2;
	private JLabel from2Error;
	private JTextField from3;
	private JLabel from3Error;;
	
	private JTextField to1;
	private JLabel to1Error;
	private JTextField to2;
	private JLabel to2Error;
	private JTextField to3;
	private JLabel to3Error;
	
	private JLabel fromLabel1;
	private JLabel fromLabel2;
	private JLabel fromLabel3;
	
	private JLabel toLabel1;
	private JLabel toLabel2;
	private JLabel toLabel3;
	
	private JComboBox<String> graphStyleBox1;
	private JComboBox<String> graphStyleBox2;
	private JComboBox<String> graphStyleBox3;
	private String [] graphStyles = {"Bar Graph", "Line Graph"};
	
	private JPanel bmi;
	private JPanel bmr;
	private JPanel caloriesBurnt;
	
	private JLabel bmiCalc;
	private JLabel bmrCalc;
	private JLabel caloriesBurntCalc;
	
	private JLabel bmiL;
	private JLabel bmrL;
	private JLabel caloriesBurntL;
	private JLabel chooseDate;
	private JTextField dateFiled;
	private JLabel dateFiledError;
	
	private JLabel profileInformation;
	private JButton addMeal;
	private JButton addExercise;
	private JButton settings;
	private JButton signOut;
	
	private JLabel username;
	private JLabel dob;
	private JLabel sex;
	private JLabel meritUnits;
	private JLabel height;
	private JLabel weight;
	String id;
	
	public MainScreen() {
		initialize();
	}
	
	private void initialize() {
		this.setFrame();
		this.setPanel();
		frame.add(panel);
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    dateFormat.setLenient(false);
		
		// profile infrormation
		ProfileManager manager = new ProfileManager();
		profileInformation = this.getLabel("Profile Infromation", 140, 50, 105, 25);
		panel.add(profileInformation);
		
		username = this.getLabel("", 30, 90, 350, 25);
		username.setText(String.format("Username: %s", manager.getLoggedIn().getUsername()));
		panel.add(username);
		
		dob = this.getLabel("", 30, 120, 350, 25);
		dob.setText(String.format("Date of Birth: %s", manager.getLoggedIn().getDob()));
		panel.add(dob);
		
		sex = this.getLabel("", 30, 150, 350, 25);
		sex.setText(String.format("Sex: %s", manager.getLoggedIn().getSex()));
		panel.add(sex);
		
		meritUnits = this.getLabel("", 30, 180, 350, 25);
		meritUnits.setText(String.format("Merit Units: %s", manager.getLoggedIn().getMeritUnits()));
		panel.add(meritUnits);
		
		height = this.getLabel("", 30, 210, 350, 25);
		height.setText(String.format("Height: %.2f", manager.getLoggedIn().getHeight()));
		panel.add(height);
		
		weight = this.getLabel("", 30, 240, 350, 25);
		weight.setText(String.format("Weight: %.2f", manager.getLoggedIn().getWeight()));
		panel.add(weight);
		
		addExercise = this.getButton("Add Exercise", 30, 390, 360, 25);
		addExercise.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				new ExerciseGUI(UUID.fromString("3a86a95e-81e1-4fae-9533-3cafaf726bc3"));
			}
		});
		panel.add(addExercise);
		
		
		addMeal = this.getButton("Add Meal", 30, 355, 175, 25);
		addMeal.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				MealUILauncher.launchMealLogScreen(UUID.fromString("3a86a95e-81e1-4fae-9533-3cafaf726bc3"));
				
			}
		});
		panel.add(addMeal);
		
		mealJournal = this.getButton("Meal Journal", 215, 355, 175, 25);
		mealJournal.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				MealUILauncher.launchMealJournalScreen(UUID.fromString("3a86a95e-81e1-4fae-9533-3cafaf726bc3"));
				
			}
		});
		panel.add(mealJournal);
		
		
		settings = this.getButton("Settings", 30, 320, 360, 25);
		panel.add(settings);
		settings.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				new SettingsScreen();
				
			}
			
		});
		
		signOut = this.getButton("Sign Out", 30, 425, 360, 25);
		signOut.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				//ExerciseLogger.unload();
				//MealLogger.unload();
				manager.logout();
				new WelcomeWindow();
				frame.setVisible(false);
				frame.dispose();
				
			}
		});
		panel.add(signOut);
		
		
		// user's plate
		pieCharts = new JPanel();
		pieCharts.setBounds(400, 460, 550, 350);
		pieCharts.setBackground(Color.WHITE);
		pieCharts.setLayout(null);
		panel.add(pieCharts);
		
		DefaultPieDataset pieDataset = new DefaultPieDataset();
		pieDataset.setValue("", 75.0);  
        JFreeChart pieChart1 = ChartFactory.createPieChart(
                "Your Plate",
                pieDataset,
                true, true, false
        );
        ChartPanel userPlate = new ChartPanel(pieChart1);
        userPlate.setBounds(0, 0, 275, 275);
        pieCharts.add(userPlate);
        ChartPanel canadaFoodGuide = new ChartPanel(Visualization.getCFChart());
        canadaFoodGuide.setBounds(275, 0, 275, 275);
        pieCharts.add(canadaFoodGuide);
        
		
		
		graphs = new JTabbedPane();
		graphs.setBounds(400, 50, 550, 400);
		
		// Calorie intake
		caloryIntake = new JPanel();
		caloryIntake.setLayout(null);
		caloryIntake.setBackground(Color.WHITE);
		
		fromLabel1 = this.getLabel("From", 30, 300, 40, 25);
		caloryIntake.add(fromLabel1);
		from1 = this.getTextField(70, 300, 100, 25);
		caloryIntake.add(from1);
		from1Error = this.getLabel("YYYY-MM-DD", 70, 320, 120, 25);
		from1Error.setForeground(Color.RED);
		from1Error.setVisible(false);
		caloryIntake.add(from1Error);
		toLabel1 = this.getLabel("To", 175, 300, 30, 25);
		caloryIntake.add(toLabel1);
		to1 = this.getTextField(200, 300, 100, 25);
		caloryIntake.add(to1);
		to1Error = this.getLabel("YYYY-MM-DD", 200, 320, 120, 25);
		to1Error.setForeground(Color.RED);
		to1Error.setVisible(false);
		caloryIntake.add(to1Error);
		graphStyleBox1 = this.getComboBox(307, 300, 100, 25);
		caloryIntake.add(graphStyleBox1);
		plot1 = this.getButton("Plot", 414, 300, 100, 25);
		caloryIntake.add(plot1);
		caloryIntakePanel = new ChartPanel(null);
		plot1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				boolean check1 = true;
			    try {
					dateFormat.parse(from1.getText());
					from1Error.setVisible(false);            
				} 
				catch (ParseException a) {
					    check1 = false;
					    from1Error.setVisible(true); 
				}
			    
			    try {
					dateFormat.parse(to1.getText());
					to1Error.setVisible(false);
					            
				} 
				catch (ParseException a) {
					    check1 = false;
					    to1Error.setVisible(true);
				}
			    
			    if(check1) {
			    	Visualization visualization = new Visualization();
					JFreeChart graph1 = visualization.graphCaloryIntake(LocalDate.parse(from1.getText()), LocalDate.parse(to1.getText()), graphStyleBox1.getSelectedItem().toString(), UUID.fromString("3a86a95e-81e1-4fae-9533-3cafaf726bc3"));
					caloryIntakePanel.setChart(graph1);
					caloryIntakePanel.setBounds(0, 0, 550, 270);
			    }
				
			}
			
		});
		caloryIntake.add(caloryIntakePanel);
		graphs.add("Calorie Intake", caloryIntake);
		
		
		
		// TDEE
		tdee = new JPanel();
		tdee.setLayout(null);
		tdee.setBackground(Color.WHITE);
		
		fromLabel2 = this.getLabel("From", 30, 300, 40, 25);
		tdee.add(fromLabel2);
		from2 = this.getTextField(70, 300, 100, 25);
		tdee.add(from2);
		from2Error = this.getLabel("YYYY-MM-DD", 70, 320, 120, 25);
		from2Error.setForeground(Color.RED);
		from2Error.setVisible(false);
		tdee.add(from2Error);
		toLabel2 = this.getLabel("To", 175, 300, 30, 25);
		tdee.add(toLabel2);
		to2 = this.getTextField(200, 300, 100, 25);
		tdee.add(to2);
		to2Error = this.getLabel("YYYY-MM-DD", 200, 320, 120, 25);
		to2Error.setForeground(Color.RED);
		to2Error.setVisible(false);
		tdee.add(to2Error);
		graphStyleBox2 = this.getComboBox(307, 300, 100, 25);
		tdee.add(graphStyleBox2);
		plot2 = this.getButton("Plot", 414, 300, 100, 25);
		tdee.add(plot2);
		
		plot2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				boolean check2 = true;
			    try {
					dateFormat.parse(from2.getText());
					from2Error.setVisible(false);            
				} 
				catch (ParseException a) {
					    check2 = false;
					    from2Error.setVisible(true); 
				}
			    
			    try {
					dateFormat.parse(to2.getText());
					to2Error.setVisible(false);
					            
				} 
				catch (ParseException a) {
					    check2 = false;
					    to2Error.setVisible(true);
				}
			    
			    if (check2) {
				//Visualization visualization = new Visualization;
				//JFreeChart graph2 = visualisation.getCaloriesGraph(from2.getText(), to2.getText(), graphStyleBox2.getSelectedItem());
			
			    }
			}
					
		});
		
		CategoryDataset dataset2 = createDataset();
        JFreeChart chart2 = ChartFactory.createBarChart(
                "Energy Expendeture",
                "",
                "",
                dataset2
        );
		tdeePanel = new ChartPanel(chart2);
		tdeePanel.setBounds(0, 0, 550, 270);
		tdee.add(tdeePanel);
		
		graphs.add("Energy Expendeture", tdee);
		
		// nutrient intake
		nutrientIntake = new JPanel();
		nutrientIntake.setLayout(null);
		nutrientIntake.setBackground(Color.WHITE);
		
		fromLabel3 = this.getLabel("From", 30, 300, 40, 25);
		nutrientIntake.add(fromLabel3);
		from3 = this.getTextField(70, 300, 100, 25);
		nutrientIntake.add(from3);
		from3Error = this.getLabel("YYYY-MM-DD", 70, 320, 120, 25);
		from3Error.setForeground(Color.RED);
		from3Error.setVisible(false);
		nutrientIntake.add(from3Error);
		toLabel3 = this.getLabel("To", 175, 300, 30, 25);
		nutrientIntake.add(toLabel3);
		to3 = this.getTextField(200, 300, 100, 25);
		nutrientIntake.add(to3);
		to3Error = this.getLabel("YYYY-MM-DD", 200, 320, 120, 25);
		to3Error.setForeground(Color.RED);
		to3Error.setVisible(false);
		nutrientIntake.add(to3Error);
		graphStyleBox3 = this.getComboBox(307, 300, 100, 25);
		nutrientIntake.add(graphStyleBox3);
		plot3 = this.getButton("Plot", 414, 300, 100, 25);
		nutrientIntake.add(plot3);
		ChartPanel nutrientIntakePanel = new ChartPanel(null);
		
		plot3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				boolean check3 = true;
			    try {
					dateFormat.parse(from3.getText());
					from3Error.setVisible(false);            
				} 
				catch (ParseException a) {
					    check3 = false;
					    from3Error.setVisible(true); 
				}
			    
			    try {
					dateFormat.parse(to3.getText());
					to3Error.setVisible(false);
					            
				} 
				catch (ParseException a) {
					    check3 = false;
					    to3Error.setVisible(true);
				}
			    if(check3) {
			    	Visualization visualization = new Visualization();
					JFreeChart graph3 = visualization.graphNutrientIntake(LocalDate.parse(from3.getText()), LocalDate.parse(to3.getText()), UUID.fromString("3a86a95e-81e1-4fae-9533-3cafaf726bc3"));
					nutrientIntakePanel.setChart(graph3);
					nutrientIntakePanel.setBounds(0, 0, 550, 270);
			    }
			
			}
			
		});
		nutrientIntake.add(nutrientIntakePanel);
		graphs.add("Nutrient Intake", nutrientIntake);
		panel.add(graphs);
		
		// bmi
		bmi = new JPanel();
		bmi.setLayout(null);
		bmi.setBounds(30, 460, 360, 108);
		bmi.setBackground(Color.WHITE);
		panel.add(bmi);
		bmiCalc = this.getLabel("BMI Calculator", 10, 10, 100, 25);
		bmi.add(bmiCalc);
		bmiL = this.getLabel(String.format("Body mass index = %.2f", manager.getLoggedIn().getBmi()), 10, 37, 150, 25);
		bmi.add(bmiL);
		calculate1 = this.getButton("Calculate", 10, 70, 100, 25);
		calculate1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				bmiL.setText(String.format("Body mass index = %.2f", Calculation.calcBMI(manager.getLoggedIn().getWeight(), manager.getLoggedIn().getHeight(), manager.getLoggedIn().getMeritUnits())));
			}
		});
		bmi.add(calculate1);
		
		// bmr
		bmr = new JPanel();
		bmr.setLayout(null);
		bmr.setBounds(30, 581, 360, 108);
		bmr.setBackground(Color.WHITE);
		panel.add(bmr);
		bmrCalc = this.getLabel("BMR Calculator", 10, 10, 100, 25);
		bmr.add(bmrCalc);
		bmrL = this.getLabel(String.format("Basal metabolic rate = %.2f", manager.getLoggedIn().getBmr()), 10, 37, 200, 25);
		bmr.add(bmrL);
		calculate2 = this.getButton("Calculate", 10, 70, 100, 25);
		calculate2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				bmrL.setText(String.format("Basal metabolic rate = %.2f", Calculation.calcBMR(manager.getLoggedIn().getWeight(), 
						manager.getLoggedIn().getHeight(), manager.getLoggedIn().getSex(),
						AgeCalculator.getAge(manager.getLoggedIn().getDob()), manager.getLoggedIn().getMeritUnits())));
			}
			
		});
		bmr.add(calculate2);
		
		// fat burnt
		caloriesBurnt = new JPanel();
		caloriesBurnt.setLayout(null);
		caloriesBurnt.setBounds(30, 702, 360, 108);
		caloriesBurnt.setBackground(Color.WHITE);
		panel.add(caloriesBurnt);
		caloriesBurntCalc = this.getLabel("Fat Burnt Estimator", 10, 10, 150, 25);
		caloriesBurnt.add(caloriesBurntCalc);
		caloriesBurntL = this.getLabel("You will burn - kg", 10, 40, 100, 25);
		caloriesBurnt.add(caloriesBurntL);
		chooseDate = this.getLabel("Choose date", 120, 70, 80, 25);
		caloriesBurnt.add(chooseDate);
		dateFiled = this.getTextField(200, 70, 100, 25);
		caloriesBurnt.add(dateFiled);
		dateFiledError = this.getLabel("YYYY-MM-DD", 210, 45, 100, 25);
		dateFiledError.setForeground(Color.RED);
		dateFiledError.setVisible(false);
		caloriesBurnt.add(dateFiledError);
		calculate3 = this.getButton("Estimate", 10, 70, 100, 25);
		calculate3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				boolean check = true;
				try {
					dateFormat.parse(dateFiled.getText());
					dateFiledError.setVisible(false);
					            
				} 
				catch (ParseException a) {
					    check = false;
					    dateFiledError.setVisible(true);
				}
				if (check) {
					caloriesBurntL.setText(String.format("You will burn %.2f kg", Calculation.calcFatBurnt(LocalDate.parse(dateFiled.getText()))));
				}
			}
			
		});
		caloriesBurnt.add(calculate3);
	}
	
	private CategoryDataset createDataset() {
		// TODO Auto-generated method stub
		return null;
	}

	private void setFrame() {
		frame = new JFrame();
		frame.setTitle("Profile");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setSize(1000, 900);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setVisible(true);
	}
	private void setPanel() {
		panel = new JPanel();
		panel.setLayout(null);
	}
	private JTextField getTextField(int x, int y, int l, int w) {
		JTextField textField = new JTextField();
		textField.setBounds(x, y, l, w);
		return textField;
	}
	private JLabel getLabel(String text, int x, int y, int l, int w) {
		JLabel label = new JLabel(text);
		label.setBounds(x, y, l, w);
		return label;
	}
	
	private JComboBox<String> getComboBox(int x, int y, int l, int w) {
		JComboBox<String> box = new JComboBox<>(graphStyles);
		box.setBounds(x, y, l, w);
		return box;
	}
	
	private JButton getButton(String text, int x, int y, int l, int w) {
		JButton button = new JButton(text);
		button.setBounds(x, y, l, w);
		return button;
	}
}
